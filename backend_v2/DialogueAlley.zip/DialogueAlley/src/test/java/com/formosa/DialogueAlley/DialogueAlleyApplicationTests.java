package com.formosa.DialogueAlley;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DialogueAlleyApplicationTests {

	@Test
	void contextLoads() {
	}

}
